==============================================================================
oZone3D.Net FurMark
==============================================================================

OpenGL GPU Overclocking Validation Utility

"Heat Up Your GPU Man!"


[1 - HOMEPAGE]
[2 - DESCRIPTION]
[3 - CONTROLS]
[4 - CHANGELOG]
[5 - AUTHOR]
[6 - CREDITS]
[7 - DONATE]
[8 - TERMS]



	
[1 - HOMEPAGE]
	http://www.ozone3d.net/benchmarks/fur/
	
	Online Scores: http://www.ozone3d.net/benchmarks/furmark_scores.php
	
	All latest news about FurMark at Geeks3D.com:
	http://www.geeks3d.com/?tag=furmark
  
  FurMark related links:
  - http://www.geeks3d.com/20091125/radeon-hd-5970-overclocking-problems-with-furmark/
  - http://www.geeks3d.com/20090925/ati-cypress-radeon-hd-5870-cards-have-hardware-protection-against-power-virus-like-furmark-and-occt/
  - http://www.geeks3d.com/20090916/furmark-slowdown-by-catalyst-graphics-drivers-is-intentional/
  - http://www.geeks3d.com/20090914/catalyst-9-8-and-9-9-improve-protection-against-furmark/
  - http://www.geeks3d.com/20091209/geforce-gtx-275-vrm-damaged-by-furmark/
  - http://www.geeks3d.com/20090226/thermalright-does-not-like-furmark/
  - http://www.geeks3d.com/20090713/tutorial-geforce-gts-250-overclocking/


[2 - DESCRIPTION]
	OpenGL Benchmark / GPU stress test application. This benchmark is focused on fur rendering. 
	Very handy to quickly benchmark a graphics card.
	
	This benchmark requires an OpenGL 2.0 compliant graphics controller and lot of GPU power!

	Please, do not hesitate to drop me an email (jegx@ozone3d.net) if you encouter some bugs.
	
	Run Modes:
	-----------
	- Benchmarking Mode: performs a benchmark with score at the end.
	- Stability Test Mode: runs the benchmark until the user presses the ESC key.
	  This mode is useful to test your graphics card during your overclocking sessions!
	  
	Options:
	--------
	- Xtreme burning mode: increase the fur rendering workload to produce more power draw.
	- Fullscreen
	- Window size selection (standard or custom)
	- MSA samples selection
	- Benchmarking parameters: time based or frames based


[3 - CONTROLS]
	In Stability Test Mode:
	- SPACE: enables/disable fur rendering.
	- I: enables/disable the display of information.
	
	
[4 - CHANGELOG]
	http://www.ozone3d.net/benchmarks/fur/#changelog
	

[5 - AUTHOR]
	[name]: Jerome 'JeGX' GUINOT
	[email]: jegx@ozone3d.net
	[http1]: www.Geeks3D.com
	[http2]: www.oZone3D.Net
  

[6 - CREDITS]
  . Background image used in version 1.8.0 comes from 
    http://abstract.desktopnexus.com/wallpaper/48207/ 
  
	
[7 - DONATE]
If you like this software, if you find it useful and you wish to support its 
development, you can kindly make a donation: http://www.ozone3d.net/donate.php

  
[8 - TERMS]
	. THIS SOFTWARE IS PROVIDED 'AS-IS', WITHOUT ANY EXPRESS OR IMPLIED WARRANTY. 
	  IN NO EVENT WILL THE AUTHOR BE HELD LIABLE FOR ANY DAMAGES ARISING FROM THE 
	  USE OF THIS SOFTWARE.
  
	. Permission is granted to anyone to use this software for any purpose, 
	  excluding commercial applications subject to the following restrictions:
  
		1. The origin of this software must not be misrepresented; you must not claim 
		   that you wrote the original software.

		2. This software is a freeware, it cannot be sold or rented.

		3. - Websites: you can copy and distribute it freely.
		   - CDROM/DVDROM or other kind of BUNDLES (graphics cards, etc.): 
			 please contact the author at jegx@ozone3d.net

		4. This notice may not be removed or altered from any distribution.
			
